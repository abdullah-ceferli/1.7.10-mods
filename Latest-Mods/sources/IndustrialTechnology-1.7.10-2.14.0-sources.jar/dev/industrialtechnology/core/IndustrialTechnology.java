package dev.industrialtechnology.core;

import cpw.mods.fml.common.Mod;
import cpw.mods.fml.common.SidedProxy;
import cpw.mods.fml.common.event.FMLPreInitializationEvent;
import cpw.mods.fml.common.event.FMLInitializationEvent;
import cpw.mods.fml.common.event.FMLServerStartingEvent;
import cpw.mods.fml.common.network.NetworkRegistry;
import cpw.mods.fml.common.network.simpleimpl.SimpleNetworkWrapper;
import cpw.mods.fml.relauncher.Side;
import dev.industrialtechnology.chunkloading.ChunkTickets;
import dev.industrialtechnology.network.ControlPacket;
import dev.industrialtechnology.network.SnapshotPacket;
import dev.industrialtechnology.quarry.MiningScheduler;
import net.minecraftforge.common.ForgeChunkManager;
import net.minecraftforge.common.MinecraftForge;
import cpw.mods.fml.common.FMLCommonHandler;
import org.apache.logging.log4j.Logger;

@Mod(modid = IndustrialTechnology.MODID, name = "Industrial Technology", version = "2.14.0",
     acceptedMinecraftVersions = "[1.7.10]", dependencies = "required-after:Forge@[10.13.4.1614,);required-after:Baubles;after:ProjectE;after:baublelicious;after:hbm;required-after:OpenComputers@[1.8.10,)")
public final class IndustrialTechnology {
    public static final String MODID = "industrialtech";
    @Mod.Instance(MODID) public static IndustrialTechnology instance;
    @SidedProxy(modId = MODID, clientSide = "dev.industrialtechnology.client.ClientProxy",
                serverSide = "dev.industrialtechnology.core.CommonProxy")
    public static CommonProxy proxy;
    public static SimpleNetworkWrapper network;
    public static Logger log;

    @Mod.EventHandler public void preInit(FMLPreInitializationEvent event) {
        log = event.getModLog();
        ModConfig.load(event.getSuggestedConfigurationFile());
        RetiredDimensionRecovery recovery = new RetiredDimensionRecovery(event.getSuggestedConfigurationFile());
        MinecraftForge.EVENT_BUS.register(recovery);
        FMLCommonHandler.instance().bus().register(recovery);
        ModRegistry.register();
        network = NetworkRegistry.INSTANCE.newSimpleChannel(MODID);
        network.registerMessage(dev.industrialtechnology.builder.BuildCommand.Handler.class,dev.industrialtechnology.builder.BuildCommand.class,14,Side.SERVER);
        network.registerMessage(dev.industrialtechnology.accessories.AccessoryCommand.Handler.class,dev.industrialtechnology.accessories.AccessoryCommand.class,13,Side.SERVER);
        network.registerMessage(ControlPacket.Handler.class, ControlPacket.class, 0, Side.SERVER);
        // The common handler delegates to the client proxy: no client class is linked on a server.
        network.registerMessage(SnapshotPacket.Handler.class, SnapshotPacket.class, 1, Side.CLIENT);
        network.registerMessage(dev.industrialtechnology.automation.ScriptUpload.Handler.class,dev.industrialtechnology.automation.ScriptUpload.class,4,Side.SERVER);
        network.registerMessage(dev.industrialtechnology.automation.ScriptDocument.Handler.class,dev.industrialtechnology.automation.ScriptDocument.class,5,Side.CLIENT);
        network.registerMessage(dev.industrialtechnology.wireless.WirelessCommand.Handler.class,dev.industrialtechnology.wireless.WirelessCommand.class,2,Side.SERVER);
        network.registerMessage(dev.industrialtechnology.wireless.WirelessSnapshot.Handler.class,dev.industrialtechnology.wireless.WirelessSnapshot.class,3,Side.CLIENT);
        network.registerMessage(dev.industrialtechnology.wireless.WirelessCatalog.Handler.class,dev.industrialtechnology.wireless.WirelessCatalog.class,6,Side.CLIENT);
        network.registerMessage(dev.industrialtechnology.capacitor.BankCommand.Handler.class,dev.industrialtechnology.capacitor.BankCommand.class,7,Side.SERVER);
        network.registerMessage(dev.industrialtechnology.capacitor.BankSnapshot.Handler.class,dev.industrialtechnology.capacitor.BankSnapshot.class,8,Side.CLIENT);
        network.registerMessage(dev.industrialtechnology.expansion.ExpansionCommand.Handler.class,dev.industrialtechnology.expansion.ExpansionCommand.class,9,Side.SERVER);
        network.registerMessage(dev.industrialtechnology.expansion.ExpansionSnapshot.Handler.class,dev.industrialtechnology.expansion.ExpansionSnapshot.class,10,Side.CLIENT);
        network.registerMessage(dev.industrialtechnology.console.ConsoleCommand.Handler.class,dev.industrialtechnology.console.ConsoleCommand.class,11,Side.SERVER);
        network.registerMessage(dev.industrialtechnology.console.ConsoleSnapshot.Handler.class,dev.industrialtechnology.console.ConsoleSnapshot.class,12,Side.CLIENT);
        ForgeChunkManager.setForcedChunkLoadingCallback(instance, new ChunkTickets.Callback());
    }
    @Mod.EventHandler public void init(FMLInitializationEvent event) {
        ModRegistry.recipes();
        dev.industrialtechnology.builder.BuilderService builder=new dev.industrialtechnology.builder.BuilderService();
        FMLCommonHandler.instance().bus().register(builder);MinecraftForge.EVENT_BUS.register(builder);
        NetworkRegistry.INSTANCE.registerGuiHandler(instance, proxy);
        FMLCommonHandler.instance().bus().register(new ServerWork());
        FMLCommonHandler.instance().bus().register(new MiningScheduler());
        MinecraftForge.EVENT_BUS.register(new ChunkTickets.WorldEvents());
        MinecraftForge.EVENT_BUS.register(new dev.industrialtechnology.quarry.OreRecognition());
        MinecraftForge.EVENT_BUS.register(new dev.industrialtechnology.wireless.TerminalSafety());
        MinecraftForge.EVENT_BUS.register(new dev.industrialtechnology.wireless.TargetAnchors());
        FMLCommonHandler.instance().bus().register(new dev.industrialtechnology.wireless.WirelessScheduler());
        dev.industrialtechnology.capacitor.BankManager banks=dev.industrialtechnology.capacitor.BankManager.events();
        MinecraftForge.EVENT_BUS.register(banks);FMLCommonHandler.instance().bus().register(banks);
        dev.industrialtechnology.solar.SolarArrays sun=new dev.industrialtechnology.solar.SolarArrays();
        MinecraftForge.EVENT_BUS.register(sun);FMLCommonHandler.instance().bus().register(sun);
        MinecraftForge.EVENT_BUS.register(new dev.industrialtechnology.railway.TrackWorld());
        MinecraftForge.EVENT_BUS.register(new dev.industrialtechnology.railway.RailwayWorld());
        FMLCommonHandler.instance().bus().register(new dev.industrialtechnology.console.ConsoleService());
        dev.industrialtechnology.integration.FactoryComputerDriver.register();
        dev.industrialtechnology.fluid.FluidMachineScheduler fluids=new dev.industrialtechnology.fluid.FluidMachineScheduler();
        MinecraftForge.EVENT_BUS.register(fluids);FMLCommonHandler.instance().bus().register(fluids);
        proxy.init();
    }
    @Mod.EventHandler public void serverStopped(cpw.mods.fml.common.event.FMLServerStoppedEvent event){dev.industrialtechnology.builder.BuilderService.clear();dev.industrialtechnology.fluid.FluidMachineScheduler.clear();dev.industrialtechnology.console.ConsoleService.clear();dev.industrialtechnology.capacitor.BankManager.clear();dev.industrialtechnology.solar.SolarArrays.clear();dev.industrialtechnology.railway.TrackWorld.clear();dev.industrialtechnology.railway.RailwayWorld.clear();}
    @Mod.EventHandler public void missingMappings(cpw.mods.fml.common.event.FMLMissingMappingsEvent event) {
        ContentMigration.ignoreRetired(event);
    }
    @Mod.EventHandler public void serverStarting(FMLServerStartingEvent event) {
        ServerWork.clear();
        MiningScheduler.clear();
    }
}
