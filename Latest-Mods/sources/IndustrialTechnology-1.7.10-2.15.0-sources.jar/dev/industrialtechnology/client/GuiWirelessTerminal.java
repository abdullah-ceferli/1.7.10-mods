package dev.industrialtechnology.client;
import java.util.*;
import net.minecraft.client.gui.*;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.renderer.*;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.*;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;
import dev.industrialtechnology.wireless.*;
import dev.industrialtechnology.core.IndustrialTechnology;
/** Compact industrial GUI. Server snapshots are read-only; only the player's own inventory has real Slots. */
public final class GuiWirelessTerminal extends GuiTooltips {
    public final TerminalContainer terminal;
    public NBTTagCompound state=new NBTTagCompound();
    private GuiTextField name,quantity;
    public GuiTextField search;
    public GuiReactorPanel reactor;
    public final CatalogAssembler catalog=new CatalogAssembler();
    private final String[] queries={"","",""};private final int[] listPages=new int[3];
    private int searchTab=-1,filterTab=-1;private String filterQuery="";private NBTTagList filterSource;private List<NBTTagCompound> filtered=new ArrayList<NBTTagCompound>();
    private String query(){return search==null?"":search.getText();}
    private List<NBTTagCompound> matches(){
        NBTTagList source=catalog.ready?catalog.rows:state.getTagList("Devices",10);String q=query();
        if(source==filterSource&&filterTab==terminal.tab&&q.equals(filterQuery))return filtered;
        filtered=new ArrayList<NBTTagCompound>();filterSource=source;filterTab=terminal.tab;filterQuery=q;
        for(int i=0;i<source.tagCount();i++){NBTTagCompound row=source.getCompoundTagAt(i);if(catalog.ready&&row.getInteger("Kind")!=terminal.tab)continue;
            if(DeviceSearch.matches(q,row.getString("Name"),row.getString("Machine"),row.getInteger("Dimension"),row.getInteger("X"),row.getInteger("Y"),row.getInteger("Z")))filtered.add(row);
        }return filtered;
    }
    private NBTTagList visibleRows(){List<NBTTagCompound> all=matches();int tab=terminal.tab;listPages[tab]=DeviceSearch.page(listPages[tab],all.size());NBTTagList rows=new NBTTagList();for(int i=listPages[tab]*6;i<Math.min(all.size(),listPages[tab]*6+6);i++)rows.appendTag(all.get(i));return rows;}
    public void receiveCatalog(WirelessCatalog packet){catalog.accept(packet);filterSource=null;updateButtons();}
    public int searchCount(){return matches().size();}
    public int searchPage(){return listPages[terminal.tab];}
    private void searchChanged(){listPages[terminal.tab]=0;queries[terminal.tab]=query();filterSource=null;updateButtons();}
    public int panelLeft(){return guiLeft;}public int panelTop(){return guiTop;}
    public void addPanelButton(int id,int x,int y,int w,int h,String label,String tip){button(id,x,y,w,h,label,tip);}
    public void sendReactor(int action,int value,String binding){send(action,value,0,binding);}
    public void openGuide(){keepDraft();guide=new GuiAutomationGuide(()->{guide=null;if(editor!=null)editor.focused=code();});guide.setWorldAndResolution(mc,width,height);}
    public void panelIcon(ItemStack icon,int x,int y){GL11.glPushAttrib(GL11.GL_ALL_ATTRIB_BITS);GL11.glPushClientAttrib(GL11.GL_CLIENT_VERTEX_ARRAY_BIT);try{RenderHelper.enableGUIStandardItemLighting();GL11.glColor4f(1,1,1,1);itemRender.renderItemAndEffectIntoGUI(fontRendererObj,mc.getTextureManager(),icon,x,y);}finally{GL11.glPopClientAttrib();GL11.glPopAttrib();}}
    public void panelTooltip(List<String> lines,int x,int y){
        int wrap=Math.min(200,Math.max(80,width-24));List<String> visible=new ArrayList<String>();
        for(String line:lines)visible.addAll(fontRendererObj.listFormattedStringToWidth(line,wrap));
        int widest=0;for(String line:visible)widest=Math.max(widest,fontRendererObj.getStringWidth(line));
        // Vanilla flips a tooltip to the left without clamping it to the viewport.
        // Keep reactor names/help inside the terminal and clear of NEI's left buttons.
        int anchor=Math.min(width-16,Math.max(x,Math.max(8,guiLeft)+widest+28));
        tooltip(visible,anchor,y);
    }
    public void panelHoverButtons(int mouseX,int mouseY){
        int x=mouseX-guiLeft,y=mouseY-guiTop;NBTTagList rows=visibleRows();if(x>=10&&x<112&&y>=48&&y<132){int i=(y-48)/14;if(i<rows.tagCount()){NBTTagCompound row=rows.getCompoundTagAt(i);tooltip(Arrays.asList(row.getString("Name"),row.getString("Status"),"id:"+row.getString("Id")),mouseX,mouseY);}return;}
        for(MetalButton b:controls)if(b.hovered(mouseX,mouseY))tooltip(Arrays.asList(b.tooltip),mouseX,mouseY);
    }
    public MultilineCodeEditor editor;public GuiAutomationGuide guide;
    private String editorDevice="",pendingDevice="",pendingText="";
    private final Map<String,String> drafts=new HashMap<String,String>();private final Set<String> dirtyDrafts=new HashSet<String>();
    private boolean code(){return terminal.tab==2&&selected()&&state.getBoolean("CodeMode")&&!state.getBoolean("ReactorView");}
    private void keepDraft(){if(editor!=null&&!editorDevice.isEmpty()){drafts.put(editorDevice,editor.model.text());if(editor.dirty)dirtyDrafts.add(editorDevice);else dirtyDrafts.remove(editorDevice);}}
    public void receiveScript(java.util.UUID device,int revision,String text){String key=device.toString();
        boolean accepted=key.equals(pendingDevice)&&text.equals(pendingText);
        if(!dirtyDrafts.contains(key)||accepted){drafts.put(key,text);dirtyDrafts.remove(key);if(key.equals(editorDevice)&&editor!=null)editor.set(text);}
        if(accepted){pendingDevice=pendingText="";if(editor!=null&&key.equals(editorDevice))editor.dirty=false;}
    }
    private String editKey="";
    private int condition,targetPage,monitorMode,tankPage;
    private List<String> energyTooltip;private int energyTooltipX,energyTooltipY;
    private boolean ruleEnabled,dirtyRule,choosingTarget;
    private final List<MetalButton> controls=new ArrayList<MetalButton>();
    private static final String[] CONDITIONS={"Contains item","Item amount reached","Inventory full","Inventory empty","Item missing"};
    public GuiWirelessTerminal(TerminalContainer terminal){super(terminal);this.terminal=terminal;xSize=316;ySize=236;}
    @Override public void initGui(){
        super.initGui();org.lwjgl.input.Keyboard.enableRepeatEvents(true);buttonList.clear();controls.clear();
        if(editor==null)editor=new MultilineCodeEditor(mc);editor.bounds(guiLeft+122,guiTop+68,182,133);
        button(1,117,7,58,15,"Monitors","Read-only item and fluid monitoring");button(2,178,7,58,15,"Controls","Real Yellow Stick redstone relays");button(3,239,7,68,15,"Automation","Blue Stick inventory conditions");
        button(4,10,144,25,13,"<","Previous linked devices");button(5,43,144,25,13,">","Next linked devices");
        button(6,245,33,58,13,"Rename","Rename the selected device");button(7,10,181,58,13,"Unlink","Remove this registration; a relay drops its stick when its chunk is loaded");
        button(9,123,94,86,13,"Manual mode","Change output mode; changing mode turns the signal OFF");button(10,214,94,88,13,"5 seconds","Pulse duration: cycle from 5 through 10 seconds");
        button(11,123,116,87,13,"Trigger pulse","Trigger once; active pulses ignore repeated requests");
        button(12,123,75,18,12,"<","Previous rule");button(13,285,75,18,12,">","Next rule; up to eight rules per Blue Stick");
        button(14,123,91,180,13,CONDITIONS[0],"Cycle condition; item rules compare exact item, metadata, and NBT");
        button(15,123,131,72,13,"Disabled","Enable or disable this rule; click Apply to save");button(16,200,131,103,13,"Apply rule","Save the ghost item, quantity, condition, and linked Yellow target");
        button(17,213,111,90,14,"Target...","Choose a linked Yellow Stick; its own pulse settings apply");
        button(18,123,70,40,12,"Items","View accessible slots on the registered face");button(19,166,70,40,12,"Tanks","View each real tank separately");
        button(20,264,70,12,12,"<","Previous inventory/tank page");button(21,291,70,12,12,">","Next inventory/tank page");
        button(28,209,70,52,12,"Energy","Stored energy and live battery input/output");
        button(29,136,134,167,12,"Batteries: Single","Toggle a straight row of touching batteries, using this battery as the center; longest axis is selected");
        button(22,123,52,73,13,"SIMPLE","Use saved button-based rules");button(23,200,52,103,13,"CODE","Use the saved command program; SIMPLE rules stay saved");
        button(24,123,205,49,13,"Save","Validate and save this draft; invalid text never replaces a working script");
        button(25,177,205,42,13,"Help","Read the classic Automation Guide without losing your draft");
        button(26,224,205,79,13,"Enable","Enable or disable the last successfully saved program");
        name=new GuiTextField(fontRendererObj,guiLeft+123,guiTop+33,116,13);name.setMaxStringLength(32);name.setText(state.getString("Name"));
        quantity=new GuiTextField(fontRendererObj,guiLeft+151,guiTop+112,56,13);quantity.setMaxStringLength(10);quantity.setText(Integer.toString(Math.max(1,state.getInteger("Minimum"))));
        search=new GuiTextField(fontRendererObj,guiLeft+10,guiTop+33,87,12);search.setMaxStringLength(64);search.setText(queries[Math.max(0,terminal.tab)]);searchTab=terminal.tab;
        button(27,100,33,12,12,"X","Clear the local device search");
        if(reactor==null)reactor=new GuiReactorPanel(this);reactor.init();
        editKey="";receive(state);
    }
    private void button(int id,int x,int y,int w,int h,String label,String tooltip){MetalButton b=new MetalButton(id,guiLeft+x,guiTop+y,w,h,label,tooltip);controls.add(b);buttonList.add(b);}
    public void receive(NBTTagCompound n){
        keepDraft();boolean wasCode=code();state=n;terminal.tab=n.getInteger("Tab");terminal.page=n.getInteger("Page");terminal.ruleIndex=n.getInteger("Rule");
        terminal.selected=WirelessData.uuid(n.getString("Selected"));terminal.reactors.view=n.getBoolean("ReactorView");terminal.reactors.type=n.getCompoundTag("Reactor").getInteger("Type");terminal.layout(code());
        if(search!=null&&searchTab!=terminal.tab){if(searchTab>=0)queries[searchTab]=search.getText();search.setText(queries[terminal.tab]);searchTab=terminal.tab;filterSource=null;}
        if(reactor!=null)reactor.receive();
        if(terminal.reactors.view&&terminal.tab==2&&terminal.reactors.type==HbmReactors.ZIRNOX){
            NBTTagList fuel=n.getCompoundTag("Reactor").getTagList("Fuels",10);ItemStack desired=null;
            for(int i=0;i<fuel.tagCount();i++){NBTTagCompound row=fuel.getCompoundTagAt(i);if(row.getInteger("Slot")==n.getCompoundTag("Reactor").getInteger("SelectedSlot")&&row.hasKey("Desired"))desired=ItemStack.loadItemStackFromNBT(row.getCompoundTag("Desired"));}
            terminal.ghost.setInventorySlotContents(0,desired);
        }
        String device=n.getString("Selected");if(editor!=null&&!device.equals(editorDevice)){editorDevice=device;editor.set(drafts.containsKey(device)?drafts.get(device):"");editor.dirty=dirtyDrafts.contains(device);}
        if(editor!=null){editor.model.limit=n.hasKey("MaxScriptLength")?n.getInteger("MaxScriptLength"):4096;editor.errorLine=n.getInteger("ScriptErrorLine");if(code()&&!wasCode)editor.focused=true;}
        String key=n.getString("Selected")+":"+n.getInteger("Rule");
        if(!key.equals(editKey)){
            editKey=key;dirtyRule=false;monitorMode=n.getCompoundTag("Energy").getBoolean("Available")?2:0;tankPage=0;choosingTarget=false;
            if(name!=null){name.setText(n.getString("Name"));name.setCursorPositionZero();}if(quantity!=null)quantity.setText(Integer.toString(Math.max(1,n.getInteger("Minimum"))));
        }
        if(!dirtyRule){condition=Math.max(0,Math.min(4,n.getInteger("Condition")));ruleEnabled=n.getBoolean("RuleEnabled");if(quantity!=null&&!quantity.isFocused())quantity.setText(Integer.toString(Math.max(1,n.getInteger("Minimum"))));}
        updateButtons();
    }
    private void send(int action,int a,int b,String text){IndustrialTechnology.network.sendToServer(new WirelessCommand(terminal.windowId,action,a,b,text));}
    private boolean selected(){return !state.getString("Selected").isEmpty();}
    private void updateButtons(){
        if(reactor!=null)reactor.layout();
        for(MetalButton b:controls){b.visible=true;b.enabled=true;b.selected=false;
            if(b.id<=3){b.selected=b.id-1==terminal.tab;continue;}
            if(b.id>=40){if(reactor!=null)reactor.update(b);else b.visible=false;continue;}
            if(b.id==28||b.id==29){NBTTagCompound energy=state.getCompoundTag("Energy");b.visible=selected()&&terminal.tab==0&&!state.getBoolean("ReactorView")&&(b.id==28||monitorMode==2);if(b.id==28)b.selected=monitorMode==2;else{b.enabled=energy.getBoolean("Available")&&energy.getBoolean("Groupable");b.displayString=energy.getBoolean("Network")?"Capacitor network":energy.getBoolean("Row")?"Batteries: Row ("+energy.getString("Axis")+")":"Batteries: Single";b.selected=energy.getBoolean("Row");}continue;}
            if(b.id==27){b.visible=true;b.enabled=!query().isEmpty();continue;}
            if(b.id==4){b.enabled=listPages[terminal.tab]>0;continue;}if(b.id==5){b.enabled=listPages[terminal.tab]+1<DeviceSearch.pages(matches().size());continue;}
            b.visible=selected();if(b.id==7){b.width=state.getBoolean("ReactorView")?38:58;b.yPosition=guiTop+(state.getBoolean("ReactorView")?185:181);}if(b.id==6||b.id==7)continue;
            if(b.id==9||b.id==10||b.id==11){b.visible=selected()&&terminal.tab==1;
                if("OTHER_DIMENSION".equals(state.getString("Status")))b.enabled=false;
                if(b.id==9)b.displayString=state.getBoolean("PulseMode")?"Pulse mode":"Manual mode";
                if(b.id==10)b.displayString=state.getInteger("Seconds")+" seconds";
                if(b.id==11)b.enabled="ONLINE".equals(state.getString("Status"))&&state.getBoolean("PulseMode")&&!state.getBoolean("Signal");continue;}
            if(b.id>=12&&b.id<=17){b.visible=selected()&&terminal.tab==2&&!code()&&!state.getBoolean("ReactorView");
                if(b.id==12)b.enabled=state.getInteger("Rule")>0;if(b.id==13)b.enabled=state.getInteger("Rule")<7;
                if(b.id==14)b.displayString=CONDITIONS[condition];if(b.id==15){b.displayString=ruleEnabled?"Enabled":"Disabled";b.selected=ruleEnabled;}
                if(b.id==17)b.displayString=shorten(state.getString("TargetName"),78);
                if(b.id==16)b.enabled=state.getTagList("Targets",10).tagCount()>0;continue;}
            if(b.id==22||b.id==23){b.visible=selected()&&terminal.tab==2;b.selected=b.id==23?code():!code()&&!state.getBoolean("ReactorView");boolean extra=state.getCompoundTag("Reactor").getInteger("Type")>0;b.xPosition=guiLeft+(b.id==22?123:extra?181:200);b.width=extra?54:b.id==22?73:103;continue;}
            if(b.id>=24){b.visible=code();if(b.id==26){b.displayString=state.getBoolean("ScriptEnabled")?"Disable":"Enable";b.selected=state.getBoolean("ScriptEnabled");}continue;}
            if(b.id>=18){b.visible=selected()&&terminal.tab==0&&!state.getBoolean("ReactorView")&&(b.id<20||monitorMode<2);
                if(b.id==18)b.selected=monitorMode==0;if(b.id==19)b.selected=monitorMode==1;
                if(b.id==20)b.enabled=(monitorMode==0?state.getInteger("DetailPage"):tankPage)>0;
                if(b.id==21)b.enabled=monitorMode==0?state.getInteger("DetailPage")+1<state.getInteger("InventoryPages"):(tankPage+1)*4<state.getTagList("Tanks",10).tagCount();
            }
        }
    }
    @Override protected void actionPerformed(GuiButton b){
        if(!b.enabled||choosingTarget)return;
        if(b.id>=40){reactor.action(b.id);updateButtons();return;}
        switch(b.id){
            case 1:case 2:case 3:dirtyRule=false;send(WirelessCommand.TAB,b.id-1,0,"");break;
            case 4:case 5:listPages[terminal.tab]=DeviceSearch.page(listPages[terminal.tab]+(b.id==5?1:-1),matches().size());break;
            case 27:search.setText("");searchChanged();search.setFocused(true);break;
            case 6:send(WirelessCommand.RENAME,0,0,name.getText());name.setFocused(false);break;
            case 7:send(WirelessCommand.UNLINK,0,0,"");break;
            case 9:send(WirelessCommand.MODE,0,0,"");break;
            case 10:send(WirelessCommand.DURATION,state.getInteger("Seconds")>=10?5:state.getInteger("Seconds")+1,0,"");break;
            case 11:send(WirelessCommand.TRIGGER,0,0,"");break;
            case 12:case 13:dirtyRule=false;send(WirelessCommand.RULE,state.getInteger("Rule")+(b.id==13?1:-1),0,"");break;
            case 14:condition=(condition+1)%5;dirtyRule=true;break;
            case 15:ruleEnabled=!ruleEnabled;dirtyRule=true;break;
            case 16:
                try{int minimum=Integer.parseInt(quantity.getText());if(minimum<1||minimum>1000000000)return;send(WirelessCommand.SAVE_RULE,condition,minimum,ruleEnabled?"1":"0");dirtyRule=false;}catch(NumberFormatException ignored){}break;
            case 22:case 23:keepDraft();send(WirelessCommand.CODE_MODE,b.id==23?1:0,0,"");break;
            case 24:keepDraft();pendingDevice=state.getString("Selected");pendingText=editor.model.text();IndustrialTechnology.network.sendToServer(new dev.industrialtechnology.automation.ScriptUpload(terminal.windowId,java.util.UUID.fromString(pendingDevice),pendingText));break;
            case 25:openGuide();break;
            case 26:send(WirelessCommand.SCRIPT_ENABLE,0,0,"");break;
            case 17:targetPage=0;choosingTarget=true;break;
            case 18:monitorMode=0;break;case 19:monitorMode=1;break;case 28:monitorMode=2;break;
            case 29:send(WirelessCommand.ENERGY_ROW,state.getCompoundTag("Energy").getBoolean("Row")?0:1,0,"");break;
            case 20:case 21:if(monitorMode==0)send(WirelessCommand.DETAIL,Math.max(0,state.getInteger("DetailPage")+(b.id==21?1:-1)),0,"");else tankPage=Math.max(0,tankPage+(b.id==21?1:-1));break;
            default:break;
        }updateButtons();
    }
    @Override protected void mouseClicked(int mouseX,int mouseY,int button){
        if(guide!=null){guide.click(mouseX,mouseY,button);return;}
        if(search!=null){search.mouseClicked(mouseX,mouseY,button);if(search.isFocused()){name.setFocused(false);quantity.setFocused(false);editor.focused=false;return;}}
        if(reactor!=null&&reactor.click(mouseX-guiLeft,mouseY-guiTop,button)){name.setFocused(false);quantity.setFocused(false);editor.focused=false;return;}
        if(code()&&editor.click(mouseX,mouseY,button))return;
        int x=mouseX-guiLeft,y=mouseY-guiTop;
        if(choosingTarget){
            NBTTagList targets=state.getTagList("Targets",10);
            if(button==0&&x>=125&&x<302&&y>=61&&y<121){int i=targetPage*5+(y-61)/12;if(i<targets.tagCount()){send(WirelessCommand.TARGET,0,0,targets.getCompoundTagAt(i).getString("Id"));choosingTarget=false;}}
            else if(button==0&&y>=124&&y<138){if(x>=125&&x<163)targetPage=Math.max(0,targetPage-1);else if(x>=263&&x<302)targetPage=Math.min(Math.max(0,(targets.tagCount()-1)/5),targetPage+1);}
            else choosingTarget=false;return;
        }
        if(button==0&&x>=10&&x<112&&y>=48&&y<132){int index=(y-48)/14;NBTTagList rows=visibleRows();
            if(index<rows.tagCount()){NBTTagCompound row=rows.getCompoundTagAt(index);send(WirelessCommand.SELECT,0,0,row.getString("Id"));
                if(terminal.tab==1&&x>=81&&"ONLINE".equals(row.getString("Status")))send(WirelessCommand.TOGGLE,0,0,"");}return;}
        if(button==0&&terminal.tab==1&&selected()&&x>=250&&x<303&&y>=116&&y<130){send(WirelessCommand.TOGGLE,0,0,"");return;}
        if(selected())name.mouseClicked(mouseX,mouseY,button);if(terminal.tab==2&&selected()&&!code()&&!state.getBoolean("ReactorView"))quantity.mouseClicked(mouseX,mouseY,button);
        boolean choosingFuel=reactor!=null&&reactor.inventoryOpen()&&mc.thePlayer.inventory.getItemStack()==null;
        super.mouseClicked(mouseX,mouseY,button);
        if(choosingFuel&&mc.thePlayer.inventory.getItemStack()!=null){reactor.closeInventory();updateButtons();}
    }
    @Override protected void keyTyped(char c,int key){
        if(guide!=null){guide.key(c,key);return;}
        if(reactor!=null&&reactor.inventoryOpen()&&(key==1||key==mc.gameSettings.keyBindInventory.getKeyCode()&&!search.isFocused()&&!name.isFocused())){reactor.closeInventory();updateButtons();return;}
        if(search!=null&&search.isFocused()){if(key==1||key==28){search.setFocused(false);return;}String before=search.getText();search.textboxKeyTyped(c,key);if(!before.equals(search.getText()))searchChanged();return;}
        if(code()&&editor.key(c,key)){keepDraft();return;}
        if(choosingTarget){if(key==1)choosingTarget=false;return;}
        if(selected()&&name.textboxKeyTyped(c,key))return;
        if(terminal.tab==2&&selected()&&!code()&&!state.getBoolean("ReactorView")&&quantity.textboxKeyTyped(c,key)){dirtyRule=true;return;}
        super.keyTyped(c,key);
    }
    @Override protected void mouseClickMove(int x,int y,int button,long duration){if(guide!=null)return;if(reactor!=null&&reactor.dragging()){reactor.drag(x-guiLeft,y-guiTop);return;}if(code()&&editor.dragging){editor.drag(x,y);return;}super.mouseClickMove(x,y,button,duration);}
    @Override protected void mouseMovedOrUp(int x,int y,int button){if(editor!=null)editor.dragging=false;if(reactor!=null)reactor.release();if(guide==null)super.mouseMovedOrUp(x,y,button);}
    @Override public void handleMouseInput(){super.handleMouseInput();int wheel=org.lwjgl.input.Mouse.getEventDWheel();if(guide==null&&code()&&wheel!=0)editor.scroll(wheel>0?-3:3);}
    @Override public void onGuiClosed(){keepDraft();org.lwjgl.input.Keyboard.enableRepeatEvents(false);super.onGuiClosed();}
    @Override public void updateScreen(){super.updateScreen();if(editor!=null)editor.tick();if(name!=null)name.updateCursorCounter();if(quantity!=null)quantity.updateCursorCounter();if(search!=null)search.updateCursorCounter();updateButtons();}
    @Override public void drawScreen(int x,int y,float partial){
        GL11.glPushAttrib(GL11.GL_ALL_ATTRIB_BITS);GL11.glPushClientAttrib(GL11.GL_CLIENT_VERTEX_ARRAY_BIT);
        try{energyTooltip=null;GL11.glColor4f(1,1,1,1);if(guide!=null)guide.drawScreen(x,y,partial);else super.drawScreen(x,y,partial);if(energyTooltip!=null)drawHoveringText(energyTooltip,energyTooltipX,energyTooltipY,fontRendererObj);}finally{GL11.glPopClientAttrib();GL11.glPopAttrib();}
    }
    @Override protected void drawGuiContainerBackgroundLayer(float partial,int mouseX,int mouseY){
        GL11.glColor4f(1,1,1,1);mc.getTextureManager().bindTexture(new ResourceLocation("industrialtech","textures/gui/wireless_terminal.png"));
        Tessellator t=Tessellator.instance;t.startDrawingQuads();t.addVertexWithUV(guiLeft,guiTop+ySize,0,0,ySize/256.0);t.addVertexWithUV(guiLeft+xSize,guiTop+ySize,0,xSize/512.0,ySize/256.0);t.addVertexWithUV(guiLeft+xSize,guiTop,0,xSize/512.0,0);t.addVertexWithUV(guiLeft,guiTop,0,0,0);t.draw();
        int[] accents={0xff70b37a,0xffd5b35d,0xff69a3d4};for(int i=0;i<3;i++)drawRect(guiLeft+117+i*61,guiTop+25,guiLeft+175+i*61,guiTop+26,accents[i]);
        if(code()){drawRect(guiLeft+76,guiTop+149,guiLeft+241,guiTop+226,0xff3b4449);drawRect(guiLeft+119,guiTop+29,guiLeft+307,guiTop+232,0xff262f35);editor.draw();}
        if(search!=null){search.drawTextBox();if(query().isEmpty()&&!search.isFocused())fontRendererObj.drawString("Search...",guiLeft+13,guiTop+35,0x74858e);}
        if(reactor!=null)reactor.background();
        if(selected()){name.drawTextBox();if(terminal.tab==2&&!code()&&!state.getBoolean("ReactorView")){quantity.drawTextBox();drawRect(guiLeft+127,guiTop+110,guiLeft+145,guiTop+128,0xff141c22);drawRect(guiLeft+128,guiTop+111,guiLeft+144,guiTop+127,0xff3a4750);}}
    }
    @Override protected void drawGuiContainerForegroundLayer(int mx,int my){
        text("Wireless Terminal",10,10,0xe3d7ba);if(!code()&&(reactor==null||!reactor.fullGrid()))text("Inventory",78,141,0xa1aaa9);
        NBTTagList rows=visibleRows();int x=mx-guiLeft,y=my-guiTop;
        for(int i=0;i<rows.tagCount();i++){
            NBTTagCompound row=rows.getCompoundTagAt(i);int py=48+i*14;boolean active=row.getString("Id").equals(state.getString("Selected"));
            drawRect(9,py-1,113,py+12,active?0xff46585f:0xff2a343b);drawRect(10,py,12,py+10,statusColor(row.getString("Status"))|0xff000000);
            text(shorten(row.getString("Name"),terminal.tab==1?63:96),15,py+2,0xc9d0cd);
            if(terminal.tab==1)slider(81,py,30,11,row.getBoolean("Signal"),"ONLINE".equals(row.getString("Status")));
        }
        text((listPages[terminal.tab]+1)+" / "+DeviceSearch.pages(matches().size()),15,state.getBoolean("ReactorView")?159:162,0x9ca8ac);
        if(matches().isEmpty()&&!query().isEmpty()){text("NO MATCHING",13,54,0xb5c2c7);text("DEVICES",13,66,0xb5c2c7);}
        if(!state.getString("Error").isEmpty())text(shorten(state.getString("Error"),180),123,55,0xd6a16d);
        if(!selected()){text("No linked devices",123,49,0xc9d0cd);text("Carry this terminal.",123,70,0x9ca8ac);text("Right-click a machine",123,83,0x9ca8ac);text("with a colored stick.",123,96,0x9ca8ac);return;}
        if(terminal.tab!=2)text(shorten(net.minecraft.util.StatCollector.translateToLocal(state.getString("Machine")),180),123,49,0xb4bdbc);
        String status=state.getString("Status");String statusLabel=status.replace('_',' ');if(terminal.tab==0&&state.getBoolean("HasInventory"))statusLabel+="  "+state.getInteger("Occupied")+"/"+state.getInteger("Slots")+" slots";if(terminal.tab!=2)text(shorten(statusLabel,174),123,60,statusColor(status));
        if(reactor!=null&&reactor.view()){reactor.draw(x,y);return;}
        if(!code()){text("Dim:"+state.getInteger("Dimension"),245,155,0x8e9a9d);text("X:"+state.getInteger("X"),245,167,0x8e9a9d);text("Y:"+state.getInteger("Y"),245,179,0x8e9a9d);text("Z:"+state.getInteger("Z"),245,191,0x8e9a9d);text(net.minecraftforge.common.util.ForgeDirection.getOrientation(state.getInteger("Side")).toString(),245,203,0x8e9a9d);}
        if(terminal.tab==0)drawMonitor(x,y);else if(terminal.tab==1){
            text("Redstone: "+(state.getBoolean("Signal")?"15":"0"),123,78,0xc9d0cd);
            if(state.getBoolean("Signal")&&state.getBoolean("TimedOutput"))text(String.format(java.util.Locale.ROOT,"%.1fs",state.getLong("Remaining")/20.0),249,78,0xd8c17d);
            slider(250,116,53,13,state.getBoolean("Signal"),"ONLINE".equals(status));
            net.minecraft.nbt.NBTTagCompound energy=state.getCompoundTag("Energy");if(energy.getBoolean("Available"))text(shorten(dev.industrialtechnology.client.GuiConsole.compact(energy.getLong("Amount"))+" / "+dev.industrialtechnology.client.GuiConsole.compact(energy.getLong("Capacity"))+" "+energy.getString("Unit"),180),123,132,0x8bc9c3);
        }else if(code()){
            String error=state.getString("ScriptError");String label=!editor.notice.isEmpty()?editor.notice:!error.isEmpty()?error:editor.dirty?"Unsaved changes":state.getBoolean("ScriptEnabled")?state.getString("AutomationStatus"):"Script disabled";
            text(shorten(label,178),123,222,error.isEmpty()&&editor.notice.isEmpty()?0x9fb4b4:0xdd9a89);
            if(x>=122&&x<304&&y>=220&&y<232)tooltip(Arrays.asList(label,"Saved program: "+(state.getBoolean("ScriptEnabled")?"enabled":"disabled"),"Save validates; Enable runs the last valid saved code."),mx,my);
        }else{
            text("Rule "+(state.getInteger("Rule")+1)+" / 8",164,77,0x9bbbd3);text(state.getBoolean("Latched")?"TRUE":"FALSE",240,77,state.getBoolean("Latched")?0x8ec793:0x9ca8ac);

            if(x>=128&&x<145&&y>=111&&y<128&&terminal.ghost.getStackInSlot(0)==null)tooltip(Arrays.asList("Ghost item: left-click to copy your carried item", "Right-click to clear; no item is consumed", "Minimum quantity is the adjacent number field"),mx,my);
            if(x>=213&&x<303&&y>=111&&y<126)tooltip(Arrays.asList(state.getString("TargetName"),"Uses the Yellow Stick's mode and "+state.getInteger("TargetSeconds")+"-second pulse"),mx,my);
        }
        if(choosingTarget){drawTargetPicker();return;}
        if(x>=10&&x<112&&y>=48&&y<132){int i=(y-48)/14;if(i<rows.tagCount()){NBTTagCompound row=rows.getCompoundTagAt(i);tooltip(Arrays.asList(row.getString("Name"),row.getString("Status"),"id:"+row.getString("Id")),mx,my);}}
        else for(MetalButton b:controls)if(b.hovered(mx,my))tooltip(Arrays.asList(b.tooltip),mx,my);
    }
    private void drawMonitor(int x,int y){
        if(monitorMode==2){drawEnergy(x,y);return;}
        text(Integer.toString((monitorMode==0?state.getInteger("DetailPage"):tankPage)+1),278,72,0xb4bdbc);
        if(!"ONLINE".equals(state.getString("Status")))return;
        if(monitorMode==0){
            NBTTagList items=state.getTagList("Items",10);
            GL11.glPushAttrib(GL11.GL_ALL_ATTRIB_BITS);try{RenderHelper.enableGUIStandardItemLighting();
                for(int i=0;i<items.tagCount();i++){int px=128+i%9*18,py=86+i/9*18;drawRect(px-1,py-1,px+17,py+17,0xff141c22);drawRect(px,py,px+16,py+16,0xff36434a);ItemStack icon=ItemStack.loadItemStackFromNBT(items.getCompoundTagAt(i).getCompoundTag("Icon"));if(icon!=null){GL11.glColor4f(1,1,1,1);itemRender.renderItemAndEffectIntoGUI(fontRendererObj,mc.getTextureManager(),icon,px,py);itemRender.renderItemOverlayIntoGUI(fontRendererObj,mc.getTextureManager(),icon,px,py,compact(items.getCompoundTagAt(i).getInteger("Count")));}}
            }finally{GL11.glPopAttrib();}
            if(!state.getBoolean("HasInventory"))text("No inventory on this face",123,91,0x9ca8ac);
            if(x>=128&&x<290&&y>=86&&y<140){int i=(y-86)/18*9+(x-128)/18;if(i<items.tagCount()){NBTTagCompound item=items.getCompoundTagAt(i);tooltip(Arrays.asList(item.hasKey("Icon")?item.getString("Name")+" x "+item.getInteger("Count"):"Empty slot", "Slot "+item.getInteger("Slot")+" | "+(item.getBoolean("Input")?"Input ":"")+(item.getBoolean("Output")?"Output":""), "Read-only: remote item transfer is unavailable"),x+guiLeft,y+guiTop);}}
        }else{
            NBTTagList tanks=state.getTagList("Tanks",10);if(tanks.tagCount()==0)text("No supported tanks",123,91,0x9ca8ac);
            for(int i=tankPage*4;i<Math.min(tanks.tagCount(),tankPage*4+4);i++){
                NBTTagCompound tank=tanks.getCompoundTagAt(i);int py=86+(i%4)*14;long amount=tank.getLong("Amount"),capacity=tank.getLong("Capacity");
                text(shorten(tankName(tank),86),123,py,0xc3cdca);text(shorten(compact(amount)+"/"+compact(capacity)+" "+tank.getString("Unit"),90),215,py,0x9db4bf);
                drawRect(123,py+9,303,py+12,0xff151e24);int bar=(int)Math.min(180,180.0*amount/Math.max(1,capacity));drawRect(123,py+9,123+bar,py+12,0xff000000|(tank.getInteger("Color")&0xffffff));
                if(x>=123&&x<303&&y>=py&&y<py+14)tooltip(Arrays.asList(tankName(tank),"Fluid ID: "+(tank.getString("FluidId").isEmpty()?"empty":tank.getString("FluidId")),"Tank "+(i+1)+" in exposed set",amount+" / "+capacity+" "+tank.getString("Unit"),String.format(java.util.Locale.ROOT,"%.1f%%",100.0*amount/Math.max(1,capacity))),x+guiLeft,y+guiTop);
            }
        }
    }
    
    private void drawEnergy(int x,int y){
        NBTTagCompound e=state.getCompoundTag("Energy");
        if(!e.getBoolean("Available")){text(shorten(e.getString("Status").replace('_',' '),180),123,90,0xb7a372);return;}
        String unit=e.getString("Unit");long amount=e.getLong("Amount"),capacity=e.getLong("Capacity");
        text(shorten(GuiConsole.compact(amount)+" / "+GuiConsole.compact(capacity)+" "+unit,180),123,85,0xd2dfdc);
        drawRect(123,96,303,100,0xff111a20);drawRect(123,96,123+(int)Math.min(180,180.0*amount/Math.max(1,capacity)),100,0xff5fa8bd);
        boolean rates=e.getBoolean("RatesAvailable");
        text(shorten("In:  "+(rates?"+"+GuiConsole.compact(e.getLong("Input"))+" "+unit+"/t":e.getBoolean("Exact")?"Measuring...":"unavailable"),180),123,103,0x82cf89);
        text(shorten("Out: "+(rates?"-"+GuiConsole.compact(e.getLong("Output"))+" "+unit+"/t":e.getBoolean("Exact")?"measuring...":"unavailable"),180),123,114,0xe28b80);
        String count=e.getInteger("Count")+(e.getInteger("Count")==1?" battery":" batteries")+(e.getBoolean("Partial")?" (partial row)":e.getBoolean("Row")?" / row "+e.getString("Axis"):e.getBoolean("Network")?" / network":"");text(shorten(count,180),123,125,e.getBoolean("Partial")?0xd8b46d:0x98abb1);
        if(x>=123&&x<303&&y>=84&&y<134){List<String> lines=new ArrayList<String>();lines.add(amount+" / "+capacity+" "+unit);
            if(rates){lines.add("Incoming: +"+e.getLong("Input")+" "+unit+"/t");lines.add("Outgoing: -"+e.getLong("Output")+" "+unit+"/t");lines.add(e.getBoolean("Network")?"Last completed tick":"Average over the last 20 completed game ticks");}
            else lines.add(e.getBoolean("Exact")?"Collecting live transfer samples...":"This battery exposes stored energy but no separate transfer meter.");
            if(e.getBoolean("NetAvailable"))lines.add("Stored energy change: "+e.getLong("Net")+" "+unit+"/t");
            if(e.getBoolean("Row")){lines.add("Row totals sum each battery's input and output.");lines.add("Transfers between row members count in both directions.");}
            if(e.getBoolean("Partial"))lines.add("Row scan stopped at an unloaded chunk or the 32-block-per-side limit.");
            energyTooltip=new ArrayList<String>();for(String line:lines)energyTooltip.addAll(fontRendererObj.listFormattedStringToWidth(line,174));energyTooltipX=x+guiLeft;energyTooltipY=y+guiTop;
        }
    }
    private static String tankName(NBTTagCompound n){String key=n.getString("Key");if(!key.isEmpty()){String translated=net.minecraft.util.StatCollector.translateToLocal(key);if(!translated.equals(key))return translated;}return n.getString("Name");}
    private void drawTargetPicker(){
        drawRect(120,45,307,140,0xff151e25);drawRect(122,47,305,138,0xff34434f);text("LINKED YELLOW STICKS",127,50,0xe0bf71);
        NBTTagList list=state.getTagList("Targets",10);for(int i=targetPage*5;i<Math.min(list.tagCount(),targetPage*5+5);i++)text(shorten(list.getCompoundTagAt(i).getString("Name"),170),127,62+i%5*12,0xd3d9d5);
        text("< Prev",127,126,0xb5c9d4);text((targetPage+1)+" / "+Math.max(1,(list.tagCount()+4)/5),194,126,0xb5c9d4);text("Next >",265,126,0xb5c9d4);
    }
    private void slider(int x,int y,int width,int height,boolean on,boolean online){
        drawRect(x,y,x+width,y+height,0xff10181c);drawRect(x+1,y+1,x+width-1,y+height-1,!online?0xff4b565d:on?0xff39734a:0xff853f38);
        int knob=on?x+width-8:x+1;drawRect(knob,y+1,knob+7,y+height-1,0xffb9c4bc);
        text(online?(on?"ON":"OFF"):"--",on?x+2:x+10,y+(height-8)/2,0xe1e6dc);
    }
    private void text(String text,int x,int y,int color){fontRendererObj.drawString(text,x,y,color);}
    private String shorten(String s,int pixels){return fontRendererObj.getStringWidth(s)<=pixels?s:fontRendererObj.trimStringToWidth(s,Math.max(6,pixels-6))+"~";}
    private static String compact(long count){if(count<1000)return Long.toString(count);return count<1000000?(count/1000)+"k":(count/1000000)+"M";}
    private static int statusColor(String status){return "ONLINE".equals(status)?0x8ec793:"OFFLINE".equals(status)||"OTHER_DIMENSION".equals(status)?0xb7a372:0xcd8e7a;}
    private void tooltip(List<String> lines,int mouseX,int mouseY){
        GL11.glPushMatrix();try{GL11.glTranslatef(-guiLeft,-guiTop,0);drawHoveringText(lines,mouseX,mouseY,fontRendererObj);}finally{GL11.glPopMatrix();}
    }
    @Override public boolean doesGuiPauseGame(){return false;}
}
