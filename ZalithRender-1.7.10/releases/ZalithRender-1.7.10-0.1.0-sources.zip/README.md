# ZalithRender

An original **Minecraft Forge 1.7.10** client renderer by **Zahin**, targeting **Zalith Launcher 1 and Zalith Launcher 2**.

Version **0.1.0** is an experimental chunk-rendering build. It is a separate implementation; it does not contain Angelica or Beddium runtime code. It is not affiliated with either Zalith project.

## Downloads

- [ZalithRender-1.7.10-0.1.0.jar](releases/ZalithRender-1.7.10-0.1.0.jar)
- [Complete corresponding source](releases/ZalithRender-1.7.10-0.1.0-sources.zip)
- [Verification report](releases/verification.json)
- [SHA-256 checksums](releases/SHA256SUMS.txt)

**Android device testing and gameplay FPS measurements are still needed.** Both launchers' actual LWJGL Java libraries pass desktop native graphics checks. Those checks use an NVIDIA compatibility context, not an Android Mali driver.

## What it does

Minecraft's original chunk builder still creates the complete geometry and display lists. ZalithRender captures eligible geometry once and uploads it into vertex buffers. During chunk drawing it replays cached meshes through the older fixed-function pipeline. Vanilla visibility, ambient occlusion, lightmaps, transparency sorting, textures and draw order remain in charge.

The implementation uses OpenGL 1.3/1.5 APIs. It does not require OpenGL 3.3 core, compute shaders, native platform binaries or GPU-fence dispatch through a separate service layer.

- Normal render distance, resolution, particles and graphics settings remain unchanged.
- Ordinary modded ores and crops that inherit vanilla rendering can be cached.
- Custom block renderers, unusual tessellator layouts and multiple-draw chunk passes keep Minecraft's original rendering.
- Custom Forge world-render hooks trigger normal rendering so their additional graphics are retained.
- GPU mesh memory defaults to **32 MiB**, with **8 additional uploads per frame**, **2 MiB per mesh** and **4,096 entries** at most. These are configurable bounds, not claims about total Minecraft memory use. A growable CPU staging buffer is separate; original Minecraft display lists remain allocated for fallback.
- Chunk replacement, translucent re-sorting, world unloading, cache eviction and lost GPU-buffer detection invalidate the relevant cached data.
- The primitive-key cache avoids allocating an Integer for each chunk lookup.

This first release focuses on terrain rendering. It does not implement Angelica's shader-pack support, dynamic lights, custom font system, entity batching or other full-suite features. FPS gains on a specific phone are not established.

## Install

1. Close Minecraft and use a copy of the instance for the first test.
2. Remove Angelica, including any `angelica-*-zalith.*.jar`, from that test instance. Install one ZalithRender JAR in `mods`.
3. Use **Minecraft 1.7.10, Forge 10.13.4.1614 and Java 8**. Begin with **GL4ES** in either launcher. MobileGlues requires an appropriate fixed-function compatibility layer, such as SFPEW; raw core-profile-only rendering is not the target of this build.
4. Keep the other mods' required dependencies. ZalithRender adds no dependency on GTNHLib, FalsePatternLib or UniMixins. Hodgepodge and BugTorch can stay, although full-pack gameplay needs testing.
5. Open a new test world and press **F3**. The `ZalithRender` line shows cached and native chunks and cache memory. Native fallback is expected around unsupported custom geometry; those chunks are still drawn.

This is client-side work: it adds no items, blocks, recipes or world-save format. It does not need to be added to the LAN server or other players' clients.

When another rendering replacement is detected, it retains normal Minecraft rendering rather than stacking pipelines. Test it separately from Angelica, Beddium, Neodymium, FalseTweaks, OptiFine, FastCraft, BetterFoliage and RPLE.

To uninstall, close Minecraft and remove this JAR. The generated `config/zalithrender.cfg` contains only this mod's options.

## Validation

The checks cover both MCP development and SRG runtime field/method names, the four real Minecraft target classes, rejection of unknown layouts, cache lookup and removal, all 16 vertex-attribute combinations, textures, lightmaps, blending, transparency re-sorting, mixed cached/native rendering, custom geometry, memory and upload limits, chunk release, context-buffer loss, and GL state restoration.

Native tests also load the actual transformed Minecraft Tessellator and compare its normal display-list pixels against the captured vertex-buffer result. They run against the pinned Zalith 1 LWJGL 3.3.6 and Zalith 2 LWJGL 3.3.3 libraries. The report records the tested desktop GL version and explicitly marks physical Android testing as false.

These are renderer and integration fixtures, not a full modpack gameplay benchmark.

## Build

Use a **Java 8 JDK**, Python 3.9+ and a ForgeGradle development cache for Forge 10.13.4.1614.

```powershell
.\build.ps1 -JavaHome 'C:\path\to\jdk8'
```

The script uses a sibling Industrial Technology development cache when present. Otherwise it prepares a local Forge workspace through the Gradle wrapper. You can set `-Cache` explicitly.

For the direct build and native verification:

```powershell
python build.py --java-home 'C:\path\to\jdk8' --cache 'C:\path\to\gradle-user-home'
```

`--offline` uses verified cached test libraries. `--skip-native` builds and performs the mapping checks without claiming native graphics validation. Windows is currently the host for the native checks. Native library inputs and hashes are pinned in `test-dependencies.lock.json` and are not included in the runtime mod.

Build outputs go into `dist`. After reviewing a build, copy its JAR, source ZIP, report and checksums into `releases` for publishing.

## GitHub layout

`src`, `tests`, build scripts, the Gradle wrapper, licenses and documentation are intended to be tracked. `releases` deliberately contains the reviewed build. Generated classes, private game instances, caches, downloaded test libraries and logs are ignored. The folder can live in a monorepo or be uploaded as its own repository.

## License

Original project code is provided under the [MIT license](LICENSE). See [THIRD_PARTY.md](THIRD_PARTY.md) for the unmodified build tools and external APIs used for development and testing.
